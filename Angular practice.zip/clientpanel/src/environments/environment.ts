// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase:{
    apiKey: "AIzaSyDC9ye9_AslJHpCgR6Tblk8M5W1HjGlrQs",
    authDomain: "myangularclientpanelproject.firebaseapp.com",
    databaseURL: "https://myangularclientpanelproject.firebaseio.com",
    projectId: "myangularclientpanelproject",
    storageBucket: "myangularclientpanelproject.appspot.com",
    messagingSenderId: "214393291831",
    appId: "1:214393291831:web:a9bd7703c5b8b3fc39abb2"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
