export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyDC9ye9_AslJHpCgR6Tblk8M5W1HjGlrQs",
    authDomain: "myangularclientpanelproject.firebaseapp.com",
    databaseURL: "https://myangularclientpanelproject.firebaseio.com",
    projectId: "myangularclientpanelproject",
    storageBucket: "myangularclientpanelproject.appspot.com",
    messagingSenderId: "214393291831",
    appId: "1:214393291831:web:a9bd7703c5b8b3fc39abb2"
  }
};
