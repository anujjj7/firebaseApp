import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Client } from '../models/Client';

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  clients: Observable<Client[]>;
  client: Observable<Client>;
  clientsCollection: AngularFirestoreCollection<Client>;
  clientDoc: AngularFirestoreDocument<Client>;

  constructor(private afs: AngularFirestore) {
    this.clientsCollection = afs.collection('clients', ref => ref.orderBy('lastName', 'asc'));
  }

  getClients(): Observable<Client[]> {
    this.clients = this.clientsCollection.snapshotChanges().pipe(
      map(actions => actions.map(a => {
        const data = a.payload.doc.data() as Client;
        const id = a.payload.doc.id;
        return { id, ...data };
      }))
    );
    return this.clients;
  }

  getClient(id: string): Observable<Client> {
    this.clientDoc = this.afs.doc<Client>(`clients/${id}`);
    this.client = this.clientDoc.snapshotChanges().pipe(map(action => {
      if (action.payload.exists === false) {
        return null;
      } else {
        const data = action.payload.data() as Client;
        data.id = action.payload.id;
        return data;
      }
    }));
    return this.client;
  }

  addClient(clientVar: Client) {
    this.clientsCollection.add(clientVar);
    console.log(clientVar, ' added');
  }

  updateClient(client: Client) {
    // this.clientDoc = this.afs.doc(`clients/${client.id}`);   //Already set in getClient()
    this.clientDoc.update(client);
  }

  deleteClient(id: string) {
    // this.clientDoc = this.afs.doc('clients/' + id);          //Already set in getClient()
    this.clientDoc.delete();
  }
}