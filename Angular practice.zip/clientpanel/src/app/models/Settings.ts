export interface Settings{
    allowRegisteration?:boolean,
    disableBalanceOnAdd?:boolean,
    disableBalanceOnEdit?:boolean
}