import { Component, OnInit } from '@angular/core';
import { Client } from 'src/app/models/Client';
import { Router, ActivatedRoute } from '@angular/router';
import { ClientService } from '../../services/client.service';
import { SettingsService } from 'src/app/services/settings.service';

@Component({
  selector: 'app-edit-client',
  templateUrl: './edit-client.component.html',
  styleUrls: ['./edit-client.component.css']
})
export class EditClientComponent implements OnInit {

  id: string;
  client: Client = {
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    balance: 0
  };
  disableBalanceOnEdit: boolean = this.settingsService.getSettings().disableBalanceOnEdit;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private clientService: ClientService,
    private settingsService:SettingsService
  ) { }

  ngOnInit() {
    //get ID from url
    this.id = this.route.snapshot.params['id'];
    //get Client
    this.clientService.getClient(this.id).subscribe(client => this.client = client);
  }

  onSubmit({value,valid}:{value:Client,valid:boolean}){
    if(valid){
      //add id to value:Client
      value.id=this.id;
      //update Client
      this.clientService.updateClient(value);
      this.router.navigate([`/client/${this.id}`]);
    }
  }

}
