import { Component, OnInit, ViewChild } from '@angular/core';
import { Client } from 'src/app/models/Client';
import {Router} from '@angular/router';
import {ClientService} from '../../services/client.service';
import { SettingsService } from 'src/app/services/settings.service';

@Component({
  selector: 'app-add-client',
  templateUrl: './add-client.component.html',
  styleUrls: ['./add-client.component.css']
})
export class AddClientComponent implements OnInit {

  client:Client={
    firstName:'',
    lastName:'',
    email:'',
    phone:'',
    balance:0
  };
  
  disableBalanceOnAdd:boolean=this.settingsService.getSettings().disableBalanceOnAdd;

  @ViewChild('clientForm',{static:true}) form:any;

  constructor(
    private route:Router,
    private clientService:ClientService,
    private settingsService: SettingsService
    ) { }

  ngOnInit() {
  }

  onSubmit({value,valid}:{value:Client,valid:boolean}){
    if(this.disableBalanceOnAdd){
      value.balance=0;
    }
    this.clientService.addClient(value);
    this.route.navigate(['/']);
  }

}
