import { Component, OnInit } from '@angular/core';
import { Log } from 'src/app/models/Log';
import { LogService } from 'src/app/services/log.service';

@Component({
  selector: 'app-logs',
  templateUrl: './logs.component.html',
  styleUrls: ['./logs.component.css']
})
export class LogsComponent implements OnInit {
  logComp:Log;
  logsComp:Log[];
  selectedLog:Log;

  constructor(private logService:LogService) { }

  ngOnInit() {
    this.logsComp=this.logService.getLogs();
  }
  selectLog(logVar:Log){
    this.selectedLog=logVar;
    this.logService.selectLog(logVar);
  }

  removeLog(logVar:Log){
    this.logService.deleteLog(logVar);
  }

}
