import { Component, OnInit } from '@angular/core';
import { LogService } from 'src/app/services/log.service';
import { Log } from 'src/app/models/Log';

@Component({
  selector: 'app-log-form',
  templateUrl: './log-form.component.html',
  styleUrls: ['./log-form.component.css']
})
export class LogFormComponent implements OnInit {

  text:string;

  constructor(private logService:LogService) { }

  ngOnInit() {
    this.logService.selectedLog.subscribe(log=>{
      this.text=log.title;
    });
  }
  clearInput(){
    this.text='';    
  }

  onSubmit(){
    const newLog:Log={
      id:this.generateId(),
      title:this.text,
      date:new Date()
    }
    this.logService.addLog(newLog);
    this.text='';
  }

  generateId() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
}
