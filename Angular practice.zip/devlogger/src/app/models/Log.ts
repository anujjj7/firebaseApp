export interface Log{
    id:string,
    title:string,
    date:any
}