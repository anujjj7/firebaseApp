import { Injectable } from '@angular/core';
import {BehaviorSubject,Observable} from 'rxjs';
import { Log } from '../models/Log';

@Injectable({
  providedIn: 'root'
})
export class LogService {
  private logs: Log[];
  private logSource:BehaviorSubject<Log>= new BehaviorSubject<Log>({id:null,title:null,date:null});
  selectedLog:Observable<Log>=this.logSource.asObservable();

  constructor() {
    if (localStorage.getItem('logs') ==='[]') {
      this.logs = [
        { id: '1', title: 'Dev logs', date: new Date(2020, 2, 9, 9, 0, 0) },
        { id: '2', title: 'Test logs', date: new Date(2020, 2, 10, 10, 0, 0) },
        { id: '3', title: 'Prod logs', date: new Date(2020, 2, 11, 11, 0, 0) }
      ];
      localStorage.setItem('logs', JSON.stringify(this.logs));
      console.log('empty logs! Adding those 3 default logs...');
    } else {
      this.logs = JSON.parse(localStorage.getItem('logs'));
    }
  }

  getLogs(): Log[] {
    return this.logs;
  }

  selectLog(logVar:Log){
    this.logSource.next(logVar);
    console.log('Selected: '+logVar.title);
  }

  deleteLog(logVar: Log) {
    this.logs.forEach((curr, index) => {
      if (curr.id === logVar.id) {
        this.logs.splice(index, 1);
        localStorage.setItem('logs', JSON.stringify(this.logs));
        console.log('Deleted: '+logVar.title);
      }
    });
  }

  addLog(logVar:Log){
    this.logs.unshift(logVar);
    localStorage.setItem('logs',JSON.stringify(this.logs));
  }
}