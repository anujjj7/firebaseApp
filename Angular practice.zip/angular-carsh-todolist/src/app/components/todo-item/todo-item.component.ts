import { Component, OnInit, Input , Output, EventEmitter} from '@angular/core';
import { Todo } from 'src/app/models/Todo';
import {TodoService} from '../../services/todo.service';

@Component({
  selector: 'app-todo-item',
  templateUrl: './todo-item.component.html',
  styleUrls: ['./todo-item.component.css']
})

export class TodoItemComponent implements OnInit {

  @Input() todoItemInput: Todo;
  @Output() deletedTodoItem: EventEmitter<Todo>=new EventEmitter();

  constructor(private todoItemService:TodoService) { }

  ngOnInit() {
  }

  // set Dynamic CSS classes
  setClasses() {
    let classes = {
      todoItemCssClass: true,
      'is-completeCssClass': this.todoItemInput.completed
    }
    return classes;
  }

  onMyToggle(todoParam){
    // Toggle in UI
    todoParam.completed=!todoParam.completed;

    //Toggle on jsonplaceholder server
    this.todoItemService.toggleCompleted(todoParam).subscribe(todoBack=>{
      console.log(todoBack);
    });
  }

  onMyDelete(todoParam){
    this.deletedTodoItem.emit(todoParam);
  }
}