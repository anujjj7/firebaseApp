import { Component, OnInit } from '@angular/core';
import { Todo } from '../../models/Todo';
import { TodoService } from '../../services/todo.service';

@Component({
  selector: 'app-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.css']
})

export class TodosComponent implements OnInit {

  todoCompProp: Todo[];

  constructor(private myTodoService: TodoService) { }

  ngOnInit() {
    this.myTodoService.getTodos().subscribe(todos=>this.todoCompProp=todos);
  }

  deleteTodoComp(todoParam:Todo){
    // delete from UI
    this.todoCompProp=this.todoCompProp.filter(t=>t.id!==todoParam.id);

    //delete from service
    this.myTodoService.deleteTodo(todoParam).subscribe();
  }

  addTodoComp(todoParam:Todo){
    this.myTodoService.addTodo(todoParam).subscribe(todoResp=>{
      this.todoCompProp.push(todoResp);
    });
  }
}