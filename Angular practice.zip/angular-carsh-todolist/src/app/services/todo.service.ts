import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http'
import { Todo } from '../models/Todo';
import { Observable } from 'rxjs';

const httpOptions={
  headers:new HttpHeaders({
    'Content-Type':'application/json'
  })
}

@Injectable({
  providedIn: 'root'
})
export class TodoService {

  todosUrl:string='https://jsonplaceholder.typicode.com/todos';
  todoLimit:string='?_limit=5';

  constructor(private http:HttpClient) { }

  //get Todos from server
  getTodos():Observable<Todo[]> {
    return this.http.get<Todo[]>(`${this.todosUrl}${this.todoLimit}`);
  }

  //Toggle completed
  toggleCompleted(todoParam:Todo):Observable<any>{
    const url:string=`${this.todosUrl}/${todoParam.id}`;
    return this.http.put(url,todoParam,httpOptions);
  }

  //Delete Todo
  deleteTodo(todoParam:Todo):Observable<Todo>{
    const url:string=`${this.todosUrl}/${todoParam.id}`;
    return this.http.delete<Todo>(url,httpOptions);
  }

  //Add new Todo
  addTodo(todoParam:Todo):Observable<Todo>{
    return this.http.post<Todo>(this.todosUrl,todoParam,httpOptions);
  }
}